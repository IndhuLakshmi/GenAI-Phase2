import { BrowserContext, Page } from "@playwright/test";
import { PlaywrightWrapper } from "../helpers/playwright";
import { selectors } from "./selectors";
import { LeaftapsMergeLeadPage } from "./leaftapsMergeLeadPage";
import { log } from "console";

export class LeaftapsFindLeadPopupPage extends PlaywrightWrapper {
    constructor(page: Page, context: BrowserContext) {
        super(page, context);
    }

    async getFirstResultingLead(): Promise<string> {

        const firstLead = this.page
            .locator(selectors.findLead.firstResultingLead)
            .first();

        await firstLead.waitFor({
            state: 'visible',
            timeout: 30000
        });

        const lead = await firstLead.textContent();

        console.log("First Lead ID:", lead);

        return lead?.trim() || "";
    }

    public async popupEnterFirstName(role: string) {
        console.log(await this.getTitle());
        await this.validateElementVisibility(selectors.findLeadPopup.firstNameField, "Enter FirstName")
        await this.fillAndEnter(selectors.findLeadPopup.firstNameField, "Enter FirstName", role)
    }
    public async clickfirstLeadINPopUp() {
        console.log(await this.getTitle());
        await this.wait("minWait")
        await this.click(
            selectors.findLead.firstResultingLead,
            "First Resulting Lead",
            "Link"
        );

    }

    /**
  * Click From Lead Lookup
  */

    public async clickFromLeadLookup() {

        await this.validateElementVisibility(
            selectors.mergeLead.fromLeadLookup,
            "From Lead Lookup"
        );

        const [fromLeadWindow] =
            await Promise.all([

                this.context.waitForEvent("page"),

                this.click(
                    selectors.mergeLead.fromLeadLookup,
                    "From Lead Lookup",
                    "Icon"
                )

            ]);

        await fromLeadWindow.waitForLoadState();

        this.page = fromLeadWindow;

        return this;

    }


    /**
     * Click To Lead Lookup
     */

    public async clickToLeadLookup() {

        //await this.wait("minWait")
        await this.validateElementVisibility(
            selectors.mergeLead.toLeadLookup,
            "To Lead Lookup"
        );

        await this.click(
            selectors.mergeLead.toLeadLookup,
            "To Lead Lookup",
            "Icon"
        )

        // const [toLeadWindow] =
        //     await Promise.all([

        //         this.context.waitForEvent("page"),

        //         this.click(
        //             selectors.mergeLead.toLeadLookup,
        //             "To Lead Lookup",
        //             "Icon"
        //         )

        //     ]);

        // await toLeadWindow.waitForLoadState();

        // this.page = toLeadWindow;

        // return this;

    }


    /**
     * Click Merge Button
     */

    public async clickMergeButton() {

        await this.wait("minWait")
        console.log(await this.getTitle());

        await this.validateElementVisibility(
            selectors.mergeLead.mergeButton,
            "Merge Button"
        );

        this.page.once(
            "dialog",
            async dialog => {

                console.log(
                    dialog.message()
                );

                await dialog.accept();

            }
        );

        await this.click(
            selectors.mergeLead.mergeButton,
            "Merge",
            "Button"
        );

        return this;

    }
}