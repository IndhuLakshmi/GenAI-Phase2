import { BrowserContext, Page } from "@playwright/test";
import { PlaywrightWrapper } from "../helpers/playwright";
import { credentials } from "../constants/credentialData";
import { expect } from "playwright/test";
import { URLConstants } from "../constants/urlConstants";
import { selectors } from "./selectors";
export class LeaftapsFindLeadPage extends PlaywrightWrapper {
    constructor(page: Page, context: BrowserContext) {
        super(page, context);
    }


    public async enterFirstName(role: string) {
        await this.validateElementVisibility(selectors.editLead.firstName, "Enter FirstName")
        await this.fillAndEnter(selectors.editLead.firstName, "Enter FirstName", role)
    }

    public async ClickFindLeadButton() {
        console.log(await this.getTitle());
        await this.validateElementVisibility(selectors.findLead.findLeadsButton, "Click Find Lead button")
        await this.click(selectors.findLead.findLeadsButton, "Click Find Lead button", "Button")
    }



    /**
     * Enter Lead ID
     */

    public async enterLeadId(value: string) {

        await this.validateElementVisibility(
            selectors.findLead.leadIdField,
            "Lead ID"
        );

        await this.type(
            selectors.findLead.leadIdField,
            "Lead ID",
            value
        );

        return this;

    }


    /**
     * Click Find Leads Button
     */

    public async clickFindLeadButton() {
        await this.wait("minWait")
        await this.validateElementVisibility(
            selectors.findLead.findLeadsButton,
            "Find Leads Button"
        );

        await this.click(
            selectors.findLead.findLeadsButton,
            "Find Leads",
            "Button"
        );

        return this;

    }


    /**
     * Get First Resulting Lead
     */


    async getFirstResultingLead(): Promise<string> {

        await this.wait("minWait")
        const firstLead = this.page
            .locator("(//div[contains(@class,'x-grid3-col-partyId')]//a)[1]");

        await firstLead.waitFor({
            state: 'visible',
            timeout: 30000
        });

        const lead = await firstLead.textContent();

        console.log("First Lead ID:", lead);

        return lead?.trim() || "";
    }

    /**
     * Get First Resulting First Name
     */

    public async getFirstResultingFirstName() {

        await this.validateElementVisibility(
            selectors.findLead.firstResultingFirstName,
            "First Resulting First Name"
        );

        return await this.getInnerText(
            selectors.findLead.firstResultingFirstName
        );

    }


    /**
     * Click First Resulting Lead
     */

    public async clickFirstResultingLead() {

        // await this.wait("minWait")
        // await this.validateElementVisibility(
        //     selectors.findLead.firstResultingLead
        //     , "First Resulting Lead"
        // );
        await this.wait("minWait")
        await this.click(
            selectors.findLead.firstResultingLead,
            "First Resulting Lead",
            "Link"
        );

        // return this;

    }


    /**
     * Click Phone Tab
     */

    public async clickPhoneTab() {

        await this.validateElementVisibility(
            selectors.findLead.phoneTab,
            "Phone Tab"
        );

        await this.click(
            selectors.findLead.phoneTab,
            "Phone",
            "Tab"
        );

        return this;

    }


    /**
     * Click Email Tab
     */

    public async clickEmailTab() {

        await this.validateElementVisibility(
            selectors.findLead.emailTab,
            "Email Tab"
        );

        await this.click(
            selectors.findLead.emailTab,
            "Email",
            "Tab"
        );

        return this;

    }


    /**
     * Enter Phone Number
     */

    public async enterPhoneNumber(value: string) {

        await this.validateElementVisibility(
            selectors.findLead.phoneNumberField,
            "Phone Number"
        );

        await this.type(
            selectors.findLead.phoneNumberField,
            "Phone Number",
            value
        );

        return this;

    }


    /**
     * Enter Email Address
     */

    public async enterEmailAddress(value: string) {

        await this.validateElementVisibility(
            selectors.findLead.emailAddressField,
            "Email Address"
        );

        await this.type(
            selectors.findLead.emailAddressField,
            "Email Address",
            value
        );

        return this;

    }


    /**
     * Verify Error Message
     */

    public async verifyErrorMessage(value: string) {

        await this.validateElementVisibility(
            selectors.findLead.errorMessage,
            "Error Message"
        );

        const actualErrorMessage =
            await this.getInnerText(
                selectors.findLead.errorMessage
            );

        console.log(actualErrorMessage);

        expect(actualErrorMessage)
            .toContain(value);

        return this;

    }



}
