
export const selectors = {

  // ==========================================
  // Login Page
  // ==========================================

  username:
    "#username",

  password:
    "#password",

  loginButton:
    "decorativeSubmit",

  loginError:
    "#errordiv",


  // ==========================================
  // Home Page
  // ==========================================

  loggedUserName:
    "h2",

  crmSfaLink:
    "text=CRM/SFA",

  logoutButton:
    "decorativeSubmit",


  // ==========================================
  // My Home Page
  // ==========================================

  leadsLink:
    "a:text('Leads')",


  // ==========================================
  // My Leads Page
  // ==========================================




  createLeadLink: "//a[text()='Create Lead']",
  editLeadButton: "a:text('Edit')",
  findLeadsLink: "a:text('Find Leads')",
  deleteLeadButton: ".subMenuButtonDangerous",
  mergeLeadLink: "a:text('Merge Leads')",


  // ==========================================
  // Create Lead Page
  // ==========================================

  createLead: {

    companyNameField:
      "#createLeadForm_companyName",

    firstNameField:
      "#createLeadForm_firstName",

    lastNameField:
      "#createLeadForm_lastName",

    emailField:
      "#createLeadForm_primaryEmail",

    submitButton:
      ".smallSubmit",

    verificationText: '#viewLead_firstName_sp'

  },


  // ==========================================
  // Duplicate Lead Page
  // ==========================================

  duplicateLead: {

    duplicateButton:
      ".smallSubmit"

  },


  // ==========================================
  // Edit Lead Page
  // ==========================================

  editLead: {

    companyNameField:
      "#updateLeadForm_companyName",


    updateButton:
      "(//input[@class='smallSubmit'])[1]",

    firstName:
      "(//input[@name='firstName'])[3]"


  },


  // ==========================================
  // Find Lead Page
  // ==========================================

  findLead: {

    /*
     * Original:
     * (//input[@name='firstName'])[3]
     */

    firstNameField:
      "(//input[@name='firstName'])[3]",

    leadIdField:
      "input[name='id']",

    findLeadsButton:
      "//button[@class='x-btn-text' and text()='Find Leads']",

    /*
     * Original:
     * (//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[1]
     */
    firstResultingLead:
      "(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']//a)[1]",

    /*  
     * Original:
     * //div[@class='x-grid3-hd-inner x-grid3-hd-firstName']
     */

    firstResultingFirstName:
      ".x-grid3-hd-firstName",

    phoneTab:
      "span:text-is('Phone')",

    emailTab:
      "span:text-is('Email')",

    phoneNumberField:
      "input[name='phoneNumber']",

    emailAddressField:
      "input[name='emailAddress']",

    errorMessage:
      "(//div[text()='No records to display'])[1]"

  },


  // ==========================================
  // Find Lead Popup Page
  // ==========================================

  findLeadPopup: {

    firstNameField:
      "input[name='firstName']",

    findLeadsButton:
      "button:has-text('Find Leads')",

    /*
     * Original:
     * (//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[1]
     */

    firstResultingLead:
      ".x-grid3-col-partyId a"

  },


  // ==========================================
  // View Lead Page
  // ==========================================

  viewLead: {

    firstNameText:
      "#viewLead_firstName_sp",

    findLeadsLink:
      "text=Find Leads",

    companyNameText:
      "#viewLead_companyName_sp",

    editLeadLink:
      "text=Edit",

    duplicateLeadLink:
      "text=Duplicate Lead",


  },


  // ==========================================
  // Merge Lead Page
  // ==========================================

  mergeLead: {

    /*
     * Original:
     * (//img[@alt='Lookup'])[1]
     */

    fromLeadLookup:
      "(//img[@alt='Lookup'])[1]",

    /*
     * Original:
     * (//img[@alt='Lookup'])[2]
     */

    toLeadLookup:
      "(//img[@alt='Lookup'])[2]",

    mergeButton:
      "//a[text()='Merge']"

  }

}
