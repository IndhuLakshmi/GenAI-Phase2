import { BrowserContext, Page } from "@playwright/test";
import { selectors } from "./selectors";
import { PlaywrightWrapper } from "../helpers/playwright";

export class LeaftapsEditLeadPage extends PlaywrightWrapper {
    constructor(page: Page, context: BrowserContext) {
        super(page, context);
    }



    /**
 * Update Company Name
 */

    public async updateCompanyName(value: string) {

        await this.validateElementVisibility(
            selectors.editLead.companyNameField,
            "Company Name"
        );

        await this.type(
            selectors.editLead.companyNameField,
            "Company Name",
            value
        );

        return this;

    }


    /**
     * Click Update Submit Button
     */

    public async clickUpdateSubmit() {

        await this.validateElementVisibility(
            selectors.editLead.updateButton,
            "Update Button"
        );

        await this.click(
            selectors.editLead.updateButton,
            "Update",
            "Button"
        );

        return this;

    }

}
