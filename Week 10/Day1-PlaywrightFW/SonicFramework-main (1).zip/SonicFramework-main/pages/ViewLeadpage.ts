
import { BrowserContext, Page } from "@playwright/test";
import { PlaywrightWrapper } from "../helpers/playwright";
import { credentials } from "../constants/credentialData";
import { expect } from "playwright/test";
import { URLConstants } from "../constants/urlConstants";
import { selectors } from "./selectors";
export class ViewLeadPage extends PlaywrightWrapper {

    /**
      * Verify First Name
      */

    public async verifyFirstName(value: string) {

        await this.validateElementVisibility(
            selectors.viewLead.firstNameText,
            "First Name"
        );

        const firstName =
            await this.getInnerText(
                selectors.viewLead.firstNameText
            );

        console.log(firstName);

        expect(firstName)
            .toContain(value);

        return this;

    }


    /**
     * Click Find Leads Link
     */

    public async clickFindLead() {

        await this.validateElementVisibility(
            selectors.viewLead.findLeadsLink,
            "Find Leads Link"
        );

        await this.click(
            selectors.viewLead.findLeadsLink,
            "Find Leads",
            "Link"
        );

        return this;

    }


    /**
     * Verify Company Name
     */

    public async verifyCompanyName(value: string) {

        await this.validateElementVisibility(
            selectors.viewLead.companyNameText,
            "Company Name"
        );

        const companyName =
            await this.getInnerText(
                selectors.viewLead.companyNameText
            );

        console.log(companyName);

        expect(companyName)
            .toContain(value);

        return this;

    }


    /**
     * Click Edit Lead Link
     */

    public async clickEditLeadLink() {

        await this.validateElementVisibility(
            selectors.viewLead.editLeadLink,
            "Edit Lead Link"
        );

        await this.click(
            selectors.viewLead.editLeadLink,
            "Edit Lead",
            "Link"
        );

        return this;

    }


    /**
     * Click Duplicate Lead Link
     */

    public async clickDuplicateLeadLink() {

        await this.validateElementVisibility(
            selectors.viewLead.duplicateLeadLink,
            "Duplicate Lead Link"
        );

        await this.click(
            selectors.viewLead.duplicateLeadLink,
            "Duplicate Lead",
            "Link"
        );

        return this;

    }


    /**
     * Click Delete Lead Link
     */

    public async clickDeleteLeadLink() {

        await this.validateElementVisibility(
            selectors.deleteLeadButton,
            "Delete Lead Link"
        );

        await this.click(
            selectors.deleteLeadButton,
            "Delete Lead", "Link"
        );

        return this;

    }
}