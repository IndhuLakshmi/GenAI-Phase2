import { Page, BrowserContext, expect } from "@playwright/test";
import { selectors } from "./selectors";
import { PlaywrightWrapper } from "../helpers/playwright";


export class LeaftapsCreateLeadPage extends PlaywrightWrapper {

    constructor(page: Page, context: BrowserContext) {
        super(page, context);
    }

    public async firstName(value: string) {
        await this.type(selectors.createLead.firstNameField, "First Name", value)
    }

    public async lastName(value: string) {
        await this.type(selectors.createLead.lastNameField, "Last Name", value)
    }


    public async Company(value: string) {
        await this.type(selectors.createLead.companyNameField, "Last Name", value)
    }

    public async saveButton() {
        await this.forceClick(selectors.createLead.submitButton, "Save", "Button")
    }

    public async verifyTheLead(expectedValue: string) {
        await this.validateElementVisibility(selectors.createLead.verificationText, "Lead Name")
        const leadName = await this.getInnerText(selectors.createLead.verificationText)
        console.log(leadName);
        await this.verification(selectors.createLead.verificationText, expectedValue)
    }
}