import { Page, Locator, BrowserContext } from "@playwright/test";
import { selectors } from "./selectors";
import { PlaywrightWrapper } from "../helpers/playwright";


export class LeaftapsLeadPage extends PlaywrightWrapper {
    constructor(page: Page, context: BrowserContext) {
        super(page, context);
    }

    public async clickCreateLeadLink() {
        await this.validateElementVisibility(selectors.createLeadLink, "create lead Button")
        await this.click(selectors.createLeadLink, "create lead Button", "Button")
    }
    public async clickEditLeadLink() {
        await this.validateElementVisibility(selectors.viewLead.editLeadLink, "Edit lead Button")
        await this.click(selectors.viewLead.editLeadLink, "Edit lead Button", "Button")
    }
    public async clickDeleteLeadLink() {
        await this.validateElementVisibility(selectors.deleteLeadButton, "Delete lead Button")
        await this.click(selectors.deleteLeadButton, "Delete lead Button", "Button")
    }

    public async clickMergeLeadLink() {
        await this.validateElementVisibility(selectors.deleteLeadButton, "Merge lead Button")
        await this.click(selectors.deleteLeadButton, "clickMergeLead Button", "Button")
    }

    public async clickfindLeadLink() {
         console.log(await this.getTitle());
        await this.validateElementVisibility(selectors.findLeadsLink, "Find lead Link")
        await this.click(selectors.findLeadsLink, "Find lead Link", "Button")
    }
}