import { BrowserContext, Page } from "@playwright/test";
import { selectors } from "./selectors";
import { PlaywrightWrapper } from "../helpers/playwright";

export class LeaftapsHomePage extends PlaywrightWrapper {
    constructor(page: Page, context: BrowserContext) {
        super(page, context);
    }

    public async clickLead() {
        await this.validateElementVisibility(selectors.leadsLink, "My Lead");
        await this.click(selectors.leadsLink, "My Lead", "Button");
        return this;
    }

    public async ClickMergeLead() {
        await this.validateElementVisibility(selectors.mergeLeadLink, "My Lead");
        await this.click(selectors.mergeLeadLink, "My Lead", "Button");
        return this;
    }

    public async ClickFindLead() {

        await this.validateElementVisibility(selectors.findLead.findLeadsButton, "Find Lead");
        await this.click(selectors.findLead.findLeadsButton, "Find Lead", "Button");
        return this;
    }




}