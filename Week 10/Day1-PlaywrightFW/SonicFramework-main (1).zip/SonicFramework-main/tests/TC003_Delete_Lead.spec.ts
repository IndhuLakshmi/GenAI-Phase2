import { test } from "../customFixtures/leaftapsFixture"
import { accountData } from "../data/account.interface";
import { updateJSONFile } from "../helpers/jsonDataHandler";
import testdata from "../data/DeleteLead.json"
import { LeaftapsCreateLeadPage } from "../pages/leaftapsCreateLeadPage";
import { LeaftapsEditLeadPage } from "../pages/leaftapsEditLeadPage";
//test.use({ storageState: "logins/salesforceLogin.json" })

test.describe.serial("Delete Lead form data", () => {
    for (let data of testdata) {
        test(`Delete Lead`, async ({ LeaftapsLogin, FindLeadPopUP, LeaftapsMyHome, LeaftapsHome, LeaftapsLead, LeaftapsFindLead, ViewLead }) => {

            test.info().annotations.push(
                { type: 'TestCase', description: 'Edit Lead' },
            );

            //  updateJSONFile<accountData>("../data/accountdata.json", { TC001: leadID });
            const errormsg = "No records to display";

            //div[text()='No records to display']
            await LeaftapsLogin.leaftapsLogin("ADMINLOGIN");
            await LeaftapsMyHome.clickCrmsfaLink()
            await LeaftapsHome.clickLead()
            await LeaftapsLead.clickfindLeadLink()
            await LeaftapsFindLead.enterFirstName(data.FirstName)
            // await LeaftapsFindLead.ClickFindLeadButton()

            await LeaftapsFindLead.getFirstResultingLead()
            const leadID = await LeaftapsFindLead.getFirstResultingLead();
            await FindLeadPopUP.clickfirstLeadINPopUp()
            await ViewLead.clickDeleteLeadLink()

            await LeaftapsLead.clickfindLeadLink()
            await LeaftapsFindLead.enterLeadId(leadID)
            await LeaftapsFindLead.clickFindLeadButton()

            await LeaftapsFindLead.verifyErrorMessage(errormsg)



        })
    }
})