import { test } from "../customFixtures/leaftapsFixture"
import { accountData } from "../data/account.interface";
import { updateJSONFile } from "../helpers/jsonDataHandler";
import testdata from "../data/MergeLeadData.json"
import { LeaftapsCreateLeadPage } from "../pages/leaftapsCreateLeadPage";
import { LeaftapsEditLeadPage } from "../pages/leaftapsEditLeadPage";
import { LeaftapsMergeLeadPage } from "../pages/leaftapsMergeLeadPage";
import { LeaftapsFindLeadPopupPage } from "../pages/LeaftapsFindLeadPopUPPage";
import { LeaftapsHomePage } from "../pages/leaftapsHomePage";
import { LeaftapsMyHomePage } from "../pages/leaftapsMyHomePage";
import { ViewLeadPage } from "../pages/ViewLeadpage";
//test.use({ storageState: "logins/salesforceLogin.json" })

test.describe.serial("Merge Lead form data", () => {
    for (let data of testdata) {
        test(`Merge Lead`, async ({ LeaftapsLogin, FindLeadPopUP, LeaftapsMyHome, ViewLead, LeaftapsHome, LeaftapsLead, LeaftapsFindLead }) => {

            test.info().annotations.push(
                { type: 'TestCase', description: 'Merge Lead' },
            );


            await LeaftapsLogin.leaftapsLogin("ADMINLOGIN");
            await LeaftapsMyHome.clickCrmsfaLink()
            await LeaftapsHome.clickLead()
            await LeaftapsHome.ClickMergeLead()
            await FindLeadPopUP.clickFromLeadLookup()
            await FindLeadPopUP.switchToWindowHandle(1)
            //console.log();

            await FindLeadPopUP.popupEnterFirstName(data.fromFirstName)
            const leadID = await FindLeadPopUP.getFirstResultingLead()
            await FindLeadPopUP.clickfirstLeadINPopUp()
            await FindLeadPopUP.switchToParentPage()
            await FindLeadPopUP.clickToLeadLookup()
            await FindLeadPopUP.switchToWindowHandle(1)
            await FindLeadPopUP.popupEnterFirstName(data.toFirstname)
            const toleadID = await FindLeadPopUP.getFirstResultingLead()
            console.log(toleadID)
            await FindLeadPopUP.clickfirstLeadINPopUp()





        })
    }
})