import { test } from "../customFixtures/leaftapsFixture"
import { updateJSONFile } from "../helpers/jsonDataHandler";
import testdata from "../data/EditLeadData.json"
import { LeaftapsCreateLeadPage } from "../pages/leaftapsCreateLeadPage";
import { LeaftapsEditLeadPage } from "../pages/leaftapsEditLeadPage";

//test.use({ storageState: "logins/salesforceLogin.json" })

test.describe.serial("Edit Lead form data", () => {
    for (let data of testdata) {
        test(`Edit Lead`, async ({ LeaftapsLogin, FindLeadPopUP, LeaftapsMyHome, LeaftapsHome, LeaftapsLead, LeaftapsEditLead, LeaftapsFindLead, ViewLead }) => {

            test.info().annotations.push(
                { type: 'TestCase', description: 'Edit Lead' },
            );
            await LeaftapsLogin.leaftapsLogin("ADMINLOGIN");

            await LeaftapsMyHome.clickCrmsfaLink()
            await LeaftapsHome.clickLead()
            await LeaftapsLead.clickfindLeadLink()
            await LeaftapsFindLead.enterFirstName(data.FirstName)
            // await LeaftapsFindLead.ClickFindLeadButton()
            await FindLeadPopUP.clickfirstLeadINPopUp()
            await ViewLead.clickEditLeadLink()
            await LeaftapsEditLead.updateCompanyName(data.CompanyName)
            await LeaftapsEditLead.clickUpdateSubmit()
            await ViewLead.verifyCompanyName(data.CompanyName)


        })
    }
})